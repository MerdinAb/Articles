﻿using Articles.Application.Common.Interfaces;
using Articles.Infrastructure.Persistance;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Articles.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<ArticlesDbContext>(options =>
            {
                options.UseSqlServer(
                    configuration.GetConnectionString("ArticlesDb"),
                    b => b.MigrationsAssembly(typeof(ArticlesDbContext).Assembly.FullName));
            });
            services.AddScoped<IArticlesDbContext>(provider => provider.GetService<ArticlesDbContext>());
            return services;
        }
    }
}
