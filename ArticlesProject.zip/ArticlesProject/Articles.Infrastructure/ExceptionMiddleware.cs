﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;

namespace Articles.Infrastructure
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionMiddleware> _logger;

        public ExceptionMiddleware(RequestDelegate next, ILoggerFactory loggerFactory)
        {
            _next = next;
            _logger = loggerFactory?.CreateLogger<ExceptionMiddleware>() ??
                    throw new ArgumentNullException(nameof(loggerFactory));
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Something went wrong: {ex}");
                await HandleExceptionAsync(httpContext, ex);
            }
        }

        private Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            //context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;

            string errGUID = context.Items.ContainsKey("correlation_id")
                    ? context.Items["correlation_id"] as string
                    : Guid.NewGuid().ToString();

            HttpStatusCode statusCode = HttpStatusCode.InternalServerError;
            try
            {
                if (context.Request.Path.Value.StartsWith("/api/v1"))
                {
                    _logger.LogError(
                            $"HTTP Error for Request [{context.Request.Method}] {context.Request.Path.Value.ToLower()} with status code {statusCode}");
                }
                _logger.LogError(exception, $"An API error occurred ({errGUID})!");
            }
            catch (Exception) { }

            return context.Response.WriteAsync(new ErrorDetails()
            {
                StatusCode = context.Response.StatusCode,
                Message = exception.Message,
                StackTrace = exception.StackTrace
            }.ToString());
        }
    }

    public class ErrorDetails
    {
        [JsonProperty("statusCode")]
        public int StatusCode { get; set; }
        [JsonProperty("message")]
        public string Message { get; set; }
        [JsonProperty("stackTrace")]
        public string StackTrace { get; set; }

        public override string ToString() => JsonConvert.SerializeObject(this);
    }
}
