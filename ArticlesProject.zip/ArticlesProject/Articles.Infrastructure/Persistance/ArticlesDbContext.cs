﻿using Articles.Application.Common.Interfaces;
using Articles.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Articles.Infrastructure.Persistance
{
    public class ArticlesDbContext : DbContext, IArticlesDbContext
    {
        private readonly ILogger<ArticlesDbContext> _logger;

        public ArticlesDbContext()
        {
        }

        public ArticlesDbContext(DbContextOptions<ArticlesDbContext> options, ILogger<ArticlesDbContext> logger) : base(options)
        {
            _logger = logger;
        }

        #region Entities

        public virtual DbSet<Article> Articles { get; set; }

        #endregion

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");
            modelBuilder.UseIdentityColumns();
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

            modelBuilder.Entity<Article>(entity =>
            {
                entity.ToTable("Article");

                entity.Property(e => e.title)
                    .IsRequired();
                entity.Property(e => e.content)
                    .IsRequired();
                entity.Property(e => e.publishedDate)
                    .IsRequired();
            });

            base.OnModelCreating(modelBuilder);
        }

        public IQueryable<TEnt> ReadSet<TEnt>() where TEnt : class
        {
            return Set<TEnt>().AsNoTracking();
        }

        public void EnsureDeleted()
        {
            Database.EnsureDeleted();
        }

        public virtual async Task<int> SaveChangesExAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                Validate();
                return await SaveChangesAsync(cancellationToken);
            }
            catch (Exception e)
            {
                RejectChanges();
                _logger.LogError(e, $"Database context database update error for request SaveChangesExAsync: {e.InnerException?.Message}");
                throw;
            }
        }

        private void Validate()
        {
            // ReSharper disable once ComplexConditionExpression
            var entities = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified)
                .Select(e => e.Entity)
                .ToList();

            foreach (var entity in entities)
            {
                var validationContext = new ValidationContext(entity);
                Validator.ValidateObject(entity, validationContext, validateAllProperties: true);
            }
        }

        private void RejectChanges()
        {
            foreach (var entry in ChangeTracker.Entries().Where(e => e.Entity != null).ToList())
            {
                switch (entry.State)
                {
                    case EntityState.Modified:
                    case EntityState.Deleted:
                        entry.State = EntityState.Modified; //Revert changes made to deleted entity.
                        entry.State = EntityState.Unchanged;
                        break;
                    case EntityState.Added:
                        entry.State = EntityState.Detached;
                        break;
                }
            }
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            var result = await base.SaveChangesAsync(cancellationToken);
            return result;
        }

        protected void ExecuteSqlCommand(string query)
        {
            Database.ExecuteSqlRaw(query);
        }
    }
}
