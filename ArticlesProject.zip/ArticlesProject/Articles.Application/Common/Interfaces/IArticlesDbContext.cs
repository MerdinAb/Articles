﻿using Microsoft.EntityFrameworkCore;

namespace Articles.Application.Common.Interfaces
{
    public interface IArticlesDbContext
    {
        DbSet<TEntity> Set<TEntity>() where TEntity : class;
        IQueryable<TEnt> ReadSet<TEnt>() where TEnt : class;
        Task<int> SaveChangesExAsync(CancellationToken cancellationToken = default);
        int SaveChanges();
        void EnsureDeleted();
    }
}
