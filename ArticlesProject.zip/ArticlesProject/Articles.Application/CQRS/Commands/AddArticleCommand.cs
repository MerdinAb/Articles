﻿using Articles.Application.Common.Interfaces;
using Articles.Application.CQRS.DTOs;
using Articles.Domain.Entities;
using Articles.SharedLib.Interfaces;
using Articles.SharedLib.Models;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net;

namespace Articles.Application.CQRS.Commands
{
    public record AddArticleCommand : IRequest<IResponseDataModel>
    {
        public AddArticleCommand(InsertArticleDTO articleDto)
        {
            InsertArticleDTO = articleDto;
        }

        public InsertArticleDTO InsertArticleDTO { get; set; }
    }

    public class AddArticleCommandHandler : IRequestHandler<AddArticleCommand, IResponseDataModel>
    {
        private readonly IMediator _mediator;
        private readonly IArticlesDbContext _context;
        private readonly IMapper _mapperInstance;

        public AddArticleCommandHandler(IMediator mediator,
                IArticlesDbContext context,
                IMapper mapper)
        {
            _mediator = mediator;
            _context = context;
            _mapperInstance = mapper;
        }

        public async Task<IResponseDataModel> Handle(AddArticleCommand request, CancellationToken cancellationToken)
        {
            try
            {
                if (string.IsNullOrEmpty(request.InsertArticleDTO.title))
                    return new ResponseDataModel((int)HttpStatusCode.BadRequest, "Title is mandatory");

                if (string.IsNullOrEmpty(request.InsertArticleDTO.content))
                    return new ResponseDataModel((int)HttpStatusCode.BadRequest, "Content is mandatory");

                var article = await _context.ReadSet<Article>().Where(u => u.title == request.InsertArticleDTO.title).FirstOrDefaultAsync(cancellationToken);
                if (article != null)
                    return new ResponseDataModel((int)HttpStatusCode.BadRequest, $"Article with title {request.InsertArticleDTO.title} already exists in the database.");

                Article articleToInsert = new Article();
                articleToInsert.title = request.InsertArticleDTO.title;
                articleToInsert.content = request.InsertArticleDTO.content;
                articleToInsert.publishedDate = request.InsertArticleDTO.publishedDate;

                var articleEntityResult = await _context.Set<Article>().AddAsync(articleToInsert, cancellationToken);
                await _context.SaveChangesExAsync(cancellationToken);

                return new ResponseDataModel((int)HttpStatusCode.OK, JsonConvert.SerializeObject(request.InsertArticleDTO));
            }
            catch (Exception ex)
            {
                return new ResponseDataModel((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
