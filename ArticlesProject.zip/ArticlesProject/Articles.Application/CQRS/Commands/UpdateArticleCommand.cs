﻿using Articles.Application.Common.Interfaces;
using Articles.Application.CQRS.DTOs;
using Articles.Domain.Entities;
using Articles.SharedLib.Interfaces;
using Articles.SharedLib.Models;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Net;

namespace Articles.Application.CQRS.Commands
{
    public record UpdateArticleCommand : IRequest<IResponseDataModel>
    {
        public UpdateArticleCommand(UpdateArticleDTO updateArticleDto)
        {
            UpdateArticleDTO = updateArticleDto;
        }

        public UpdateArticleDTO UpdateArticleDTO { get; set; }
    }

    public class UpdateArticleCommandHandler : IRequestHandler<UpdateArticleCommand, IResponseDataModel>
    {
        private readonly IMediator _mediator;
        private readonly IArticlesDbContext _context;
        private readonly IMapper _mapperInstance;

        public UpdateArticleCommandHandler(IMediator mediator,
                IArticlesDbContext context,
                IMapper mapper)
        {
            _mediator = mediator;
            _context = context;
            _mapperInstance = mapper;
        }

        public async Task<IResponseDataModel> Handle(UpdateArticleCommand request, CancellationToken cancellationToken)
        {
            try
            {
                if (request.UpdateArticleDTO.id == 0 || request.UpdateArticleDTO.id < 0)
                    return new ResponseDataModel((int)HttpStatusCode.BadRequest, $"Please provide a valid id");

                var article = await _context.ReadSet<Article>().Where(sa => sa.id == request.UpdateArticleDTO.id)
                    .FirstOrDefaultAsync(cancellationToken);
                if (article == null)
                    return new ResponseDataModel((int)HttpStatusCode.BadRequest, $"Article with id {request.UpdateArticleDTO.id} does not exist in the database");

                if (string.IsNullOrEmpty(request.UpdateArticleDTO.title) && string.IsNullOrEmpty(request.UpdateArticleDTO.content))
                    return new ResponseDataModel((int)HttpStatusCode.BadRequest, $"Please provide data to update");

                if (!string.IsNullOrEmpty(request.UpdateArticleDTO.title))
                    article.title = request.UpdateArticleDTO.title;

                if (!string.IsNullOrEmpty(request.UpdateArticleDTO.content))
                    article.content = request.UpdateArticleDTO.content;

                var ArticleEntityResult = _context.Set<Article>().Update(article);
                await _context.SaveChangesExAsync(cancellationToken);

                return new ResponseDataModel((int)HttpStatusCode.OK, JsonConvert.SerializeObject(request.UpdateArticleDTO));
            }
            catch (Exception ex)
            {
                return new ResponseDataModel((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
