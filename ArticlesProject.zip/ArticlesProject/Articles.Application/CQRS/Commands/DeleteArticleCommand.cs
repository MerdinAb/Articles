﻿using Articles.Application.Common.Interfaces;
using Articles.Domain.Entities;
using Articles.SharedLib.Interfaces;
using Articles.SharedLib.Models;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Net;

namespace Articles.Application.CQRS.Commands
{
    public record DeleteArticleCommand : IRequest<IResponseDataModel>
    {
        public int ArticleId { get; set; }
    }

    public class DeleteArticleCommandHandler : IRequestHandler<DeleteArticleCommand, IResponseDataModel>
    {
        private readonly IMediator _mediator;
        private readonly IArticlesDbContext _context;
        private readonly IMapper _mapperInstance;

        public DeleteArticleCommandHandler(IMediator mediator,
            IArticlesDbContext context,
            IMapper mapper)
        {
            _mediator = mediator;
            _context = context;
            _mapperInstance = mapper;
        }

        public async Task<IResponseDataModel> Handle(DeleteArticleCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var article = await _context.ReadSet<Article>().Where(a => a.id == request.ArticleId)
                    .FirstOrDefaultAsync(cancellationToken);
                if (article == null)
                    return new ResponseDataModel((int)HttpStatusCode.NotFound,
                        $"Article with Id {request.ArticleId} does not exist in the database.");

                _context.Set<Article>().Remove(article);
                await _context.SaveChangesExAsync(cancellationToken);

                return new ResponseDataModel((int)HttpStatusCode.OK, $"Article with id {article.id} was deleted.");
            }
            catch (Exception ex)
            {
                return new ResponseDataModel((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
