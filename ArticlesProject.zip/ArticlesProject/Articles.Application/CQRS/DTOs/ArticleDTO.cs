﻿namespace Articles.Application.CQRS.DTOs
{
    public class ArticleDTO
    {
        public int id {  get; set; }
        public string title { get; set; }
        public string content { get; set; }
        public DateTime publishedDate { get; set; }
    }
}
