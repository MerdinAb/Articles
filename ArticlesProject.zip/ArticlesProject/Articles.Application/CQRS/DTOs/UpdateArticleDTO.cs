﻿namespace Articles.Application.CQRS.DTOs
{
    public class UpdateArticleDTO
    {
        public int id {  get; set; }
        public string title { get; set; }
        public string content { get; set; }
    }
}
