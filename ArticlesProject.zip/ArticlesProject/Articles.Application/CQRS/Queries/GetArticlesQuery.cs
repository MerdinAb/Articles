﻿using Articles.Application.Common.Extensions;
using Articles.Application.Common.Interfaces;
using Articles.Application.CQRS.DTOs;
using Articles.Domain.Entities;
using Articles.SharedLib.Interfaces;
using Articles.SharedLib.Models;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;

namespace Articles.Application.CQRS.Queries
{
    public record GetArticlesQuery : IRequest<IResponseDataModel>
    {
        public int PageNumber { get; set; }
    }

    public class GetArticlesQueryHandler : IRequestHandler<GetArticlesQuery, IResponseDataModel>
    {
        private readonly IArticlesDbContext _context;
        private readonly IMapper _mapper;

        public GetArticlesQueryHandler(IArticlesDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IResponseDataModel> Handle(GetArticlesQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var sw = new Stopwatch();
                sw.Start();
                var query = await _context.ReadSet<Article>()
                    .Select(a => new ArticleDTO()
                    {
                        id = a.id,
                        title = a.title,
                        content = a.content,
                        publishedDate = a.publishedDate
                    }).OrderBy(a => a.id).Page(request.PageNumber, 20).ToListAsync(cancellationToken);
                return !query.Any() ? new ResponseDataModel((int)HttpStatusCode.NoContent, "There are no articles in the database.") : new ResponseDataModel((int)HttpStatusCode.OK, JsonConvert.SerializeObject(query));
            }
            catch (Exception ex)
            {
                return new ResponseDataModel((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
