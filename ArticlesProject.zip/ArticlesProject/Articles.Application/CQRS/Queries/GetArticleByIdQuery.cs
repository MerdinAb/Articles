﻿using Articles.Application.Common.Interfaces;
using Articles.Application.CQRS.DTOs;
using Articles.Domain.Entities;
using Articles.SharedLib.Interfaces;
using Articles.SharedLib.Models;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Net;

namespace Articles.Application.CQRS.Queries
{
    public record GetArticleByIdQuery : IRequest<IResponseDataModel>
    {
        public int ArticleId { get; set; }
    }

    public class GetArticleByIdQueryHandler : IRequestHandler<GetArticleByIdQuery, IResponseDataModel>
    {
        private readonly IArticlesDbContext _context;
        private readonly IMapper _mapper;

        public GetArticleByIdQueryHandler(IArticlesDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IResponseDataModel> Handle(GetArticleByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var sw = new Stopwatch();
                sw.Start();
                var query = await _context.ReadSet<Article>()
                    .Where(a => a.id == request.ArticleId)
                    .Select(a => new ArticleDTO()
                    {
                        id = a.id,
                        title = a.title,
                        content = a.content,
                        publishedDate = a.publishedDate
                    }).FirstOrDefaultAsync(cancellationToken: cancellationToken);

                return query == null ? new ResponseDataModel((int)HttpStatusCode.NotFound, $"Article with Id {request.ArticleId} not found.") : new ResponseDataModel((int)HttpStatusCode.OK, JsonConvert.SerializeObject(query));
            }
            catch (Exception ex)
            {
                return new ResponseDataModel((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}
