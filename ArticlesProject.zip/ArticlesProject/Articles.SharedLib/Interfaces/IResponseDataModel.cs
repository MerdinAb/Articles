﻿namespace Articles.SharedLib.Interfaces
{
    public interface IResponseDataModel
    {
        int StatusCode { get; set; }
        string Content { get; set; }
    }
}
