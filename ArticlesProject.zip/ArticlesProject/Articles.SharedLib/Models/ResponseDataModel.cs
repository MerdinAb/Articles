﻿using Articles.SharedLib.Interfaces;

namespace Articles.SharedLib.Models
{
    public class ResponseDataModel : IResponseDataModel
    {
        public int StatusCode { get; set; }
        public string Content { get; set; }

        public ResponseDataModel(int statusCode, string content)
        {
            StatusCode = statusCode;
            Content = content;
        }
    }
}
