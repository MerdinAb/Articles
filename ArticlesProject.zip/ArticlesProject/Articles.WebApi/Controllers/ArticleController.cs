﻿using Articles.Application.CQRS.Commands;
using Articles.Application.CQRS.DTOs;
using Articles.Application.CQRS.Queries;
using Articles.WebApi.Base;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Articles.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ArticleController : BaseApiController
    {
        private ISender _mediatR { get; }
        public ArticleController(ISender mediatR)
        {
            _mediatR = mediatR;
        }

        [HttpGet("/page/{pageNumber}")]
        public async Task<ActionResult> GetAllArticles(int pageNumber, CancellationToken cancellationToken = default)
        {
            return Ok(await _mediatR.Send(new GetArticlesQuery() { PageNumber = pageNumber }, cancellationToken));
        }

        [HttpGet("{articleId:int}")]
        public async Task<ActionResult> GeArticleById(int articleId, CancellationToken cancellationToken = default)
        {
            return Ok(await _mediatR.Send(new GetArticleByIdQuery() { ArticleId = articleId }, cancellationToken));
        }

        [HttpPost]
        public async Task<ActionResult> AddArticle(InsertArticleDTO insertArticleDTO, CancellationToken cancellationToken = default)
        {
            return Ok(await _mediatR.Send(new AddArticleCommand(insertArticleDTO), cancellationToken));
        }

        [HttpPut]
        public async Task<ActionResult> UpdateArticle(UpdateArticleDTO updateArticleDTO, CancellationToken cancellationToken = default)
        {
            return Ok(await _mediatR.Send(new UpdateArticleCommand(updateArticleDTO), cancellationToken));
        }

        [HttpDelete("articleId={articleId}")]
        public async Task<ActionResult> DeleteArticle(int articleId, CancellationToken cancellationToken = default)
        {
            return Ok(await _mediatR.Send(new DeleteArticleCommand() { ArticleId = articleId }, cancellationToken));
        }
    }
}
